from diagrams import Diagram, Cluster, Edge
from diagrams.onprem.client import User
from diagrams.programming.framework import React
from diagrams.programming.language import Javascript, Typescript
from diagrams.programming.flowchart import Document
from diagrams.onprem.network import Nginx
from diagrams.aws.storage import SimpleStorageServiceS3
from diagrams.generic.storage import Storage
from diagrams.generic.place import Datacenter

# Criar diagrama C4 de componentes do frontend
with Diagram("NeurotrackApp - Componentes do Frontend", show=False, direction="TB", filename="c4_componentes_frontend"):
    
    # Usuário
    usuario = User("Usuário\n(Pessoa Neurodivergente)")
    
    # Aplicação Frontend
    with Cluster("Aplicação Frontend (React/React Native)"):
        # Camada de Apresentação
        with Cluster("Camada de Apresentação"):
            # Páginas/Telas
            with Cluster("Páginas/Telas"):
                login_page = React("TelaLogin")
                home_page = React("TelaInicial")
                profile_page = React("TelaPerfil")
                daily_page = React("TelaEntradasDiárias")
                tasks_page = React("TelaTarefas")
                calendar_page = React("TelaAgenda")
                medication_page = React("TelaMedicação")
                ai_chat_page = React("TelaChatIA")
                reports_page = React("TelaRelatórios")
                settings_page = React("TelaConfigurações")
        
        # Camada de Componentes
        with Cluster("Componentes Reutilizáveis"):
            header = React("Cabeçalho")
            footer = React("Rodapé")
            nav_menu = React("MenuNavegação")
            mood_tracker = React("RastreadorHumor")
            task_list = React("ListaTarefas")
            calendar_view = React("VisualizaçãoCalendário")
            med_reminder = React("LembreteMedicação")
            chat_interface = React("InterfaceChat")
            
        # Camada de Gerenciamento de Estado
        with Cluster("Gerenciamento de Estado"):
            auth_state = Typescript("EstadoAutenticação")
            user_state = Typescript("EstadoUsuário")
            tasks_state = Typescript("EstadoTarefas")
            daily_state = Typescript("EstadoEntradasDiárias")
            calendar_state = Typescript("EstadoAgenda")
            med_state = Typescript("EstadoMedicação")
            
        # Camada de Serviços
        with Cluster("Serviços"):
            auth_service = Javascript("ServiçoAutenticação")
            api_service = Javascript("ServiçoAPI")
            storage_service = Javascript("ServiçoArmazenamento")
            notification_service = Javascript("ServiçoNotificação")
            
        # Camada de Adaptadores
        with Cluster("Adaptadores"):
            http_client = Javascript("ClienteHTTP")
            local_storage = Javascript("ArmazenamentoLocal")
            push_notif = Javascript("NotificaçõesPush")
    
    # API Gateway
    api_gateway = Nginx("API Gateway\n(Express.js)")
    
    # Conexões do usuário para páginas
    usuario >> Edge(label="Interage") >> login_page
    usuario >> home_page
    usuario >> profile_page
    usuario >> daily_page
    usuario >> tasks_page
    usuario >> calendar_page
    usuario >> medication_page
    usuario >> ai_chat_page
    usuario >> reports_page
    usuario >> settings_page
    
    # Conexões de páginas para componentes
    login_page >> header
    home_page >> header
    home_page >> nav_menu
    home_page >> footer
    daily_page >> mood_tracker
    tasks_page >> task_list
    calendar_page >> calendar_view
    medication_page >> med_reminder
    ai_chat_page >> chat_interface
    
    # Conexões para gerenciamento de estado
    login_page >> auth_state
    profile_page >> user_state
    tasks_page >> tasks_state
    daily_page >> daily_state
    calendar_page >> calendar_state
    medication_page >> med_state
    
    # Conexões para serviços
    auth_state >> auth_service
    user_state >> api_service
    tasks_state >> api_service
    daily_state >> api_service
    calendar_state >> api_service
    med_state >> api_service
    
    # Conexões para adaptadores
    auth_service >> http_client
    api_service >> http_client
    storage_service >> local_storage
    notification_service >> push_notif
    
    # Conexão para API Gateway
    http_client >> Edge(label="Requisições HTTP") >> api_gateway
