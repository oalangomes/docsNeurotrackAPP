from diagrams import Diagram, Cluster, Edge
from diagrams.programming.language import Javascript, Typescript
from diagrams.programming.framework import React
from diagrams.onprem.database import MongoDB
from diagrams.aws.storage import SimpleStorageServiceS3
from diagrams.generic.storage import Storage
from diagrams.generic.compute import Rack

# Criar diagrama C4 de código dos módulos principais
with Diagram("NeurotrackApp - Código dos Módulos Principais", show=False, direction="TB", filename="c4_codigo_modulos_principais"):
    
    # Módulo de Autenticação
    with Cluster("Módulo de Autenticação"):
        auth_controller = Javascript("authController.js")
        auth_middleware = Javascript("authMiddleware.js")
        auth_service = Javascript("authService.js")
        token_service = Javascript("tokenService.js")
        auth_routes = Javascript("authRoutes.js")
        
        auth_routes >> auth_controller
        auth_controller >> auth_service
        auth_service >> token_service
        auth_middleware >> token_service
    
    # Módulo de Entradas Diárias
    with Cluster("Módulo de Entradas Diárias"):
        daily_controller = Javascript("dailyEntriesController.js")
        daily_service = Javascript("dailyEntriesService.js")
        daily_model = Javascript("dailyEntry.js")
        daily_routes = Javascript("dailyEntriesRoutes.js")
        mood_analyzer = Javascript("moodAnalyzerService.js")
        
        daily_routes >> daily_controller
        daily_controller >> daily_service
        daily_service >> daily_model
        daily_service >> mood_analyzer
    
    # Módulo de Tarefas
    with Cluster("Módulo de Tarefas"):
        task_controller = Javascript("tasksController.js")
        task_service = Javascript("taskService.js")
        task_model = Javascript("task.js")
        task_breakdown = Javascript("taskBreakdown.js")
        task_routes = Javascript("tasksRoutes.js")
        
        task_routes >> task_controller
        task_controller >> task_service
        task_service >> task_model
        task_service >> task_breakdown
    
    # Módulo de IA
    with Cluster("Módulo de IA"):
        ai_controller = Javascript("aiController.js")
        ai_service = Javascript("aiService.js")
        prompt_model = Javascript("prompt.js")
        ai_adapter = Javascript("aiAdapter.js")
        ai_routes = Javascript("aiRoutes.js")
        
        ai_routes >> ai_controller
        ai_controller >> ai_service
        ai_service >> prompt_model
        ai_service >> ai_adapter
    
    # Módulo de Frontend (React)
    with Cluster("Módulo de Frontend (React)"):
        app_component = React("App.jsx")
        router = React("Router.jsx")
        auth_context = Typescript("AuthContext.tsx")
        api_client = Typescript("ApiClient.ts")
        
        # Componentes de página
        home_page = React("HomePage.jsx")
        daily_page = React("DailyEntryPage.jsx")
        tasks_page = React("TasksPage.jsx")
        ai_chat_page = React("AIChatPage.jsx")
        
        app_component >> router
        router >> home_page
        router >> daily_page
        router >> tasks_page
        router >> ai_chat_page
        
        home_page >> auth_context
        daily_page >> auth_context
        tasks_page >> auth_context
        ai_chat_page >> auth_context
        
        home_page >> api_client
        daily_page >> api_client
        tasks_page >> api_client
        ai_chat_page >> api_client
    
    # Módulo de Configuração
    with Cluster("Módulo de Configuração"):
        config = Javascript("config.js")
        db_config = Javascript("database.js")
        redis_factory = Javascript("redisFactory.js")
        http_client = Javascript("httpClient.js")
        
        config >> db_config
        config >> redis_factory
        config >> http_client
    
    # Conexões entre módulos
    auth_middleware >> daily_routes
    auth_middleware >> task_routes
    auth_middleware >> ai_routes
    
    api_client >> auth_routes
    api_client >> daily_routes
    api_client >> task_routes
    api_client >> ai_routes
