from diagrams import Diagram, Cluster, Edge
from diagrams.onprem.client import User, Client
from diagrams.onprem.compute import Server
from diagrams.onprem.database import MongoDB
from diagrams.saas.chat import Slack
from diagrams.programming.framework import React
from diagrams.onprem.network import Nginx
from diagrams.aws.integration import Eventbridge
from diagrams.generic.database import SQL
from diagrams.gcp.compute import AppEngine
from diagrams.aws.ml import Rekognition

# Criar diagrama C4 de contexto completo
with Diagram("NeurotrackApp - Diagrama de Contexto", show=False, direction="TB", filename="c4_contexto_completo"):
    
    # Usuários
    usuario = User("Usuário\n(Pessoa Neurodivergente)")
    cuidador = User("Cuidador/Familiar\n(Pessoa)")
    profissional_saude = User("Profissional de Saúde\n(Pessoa)")
    
    # Sistema principal
    with Cluster("Sistema NeurotrackApp"):
        neurotrack = Server("NeurotrackApp\n(Sistema de Software)")
        
        # Aplicações cliente
        with Cluster("Interfaces de Usuário"):
            mobile_app = Client("Aplicativo Móvel\n(iOS/Android)")
            web_app = Client("Aplicação Web\n(Navegador)")
    
    # Sistemas externos
    openai = Rekognition("OpenAI API\n(Sistema Externo)")
    google_calendar = AppEngine("Google Calendar API\n(Sistema Externo)")
    notificacoes = Slack("Sistema de Notificações\n(Sistema Externo)")
    
    # Conexões de usuários
    usuario >> Edge(label="Gerencia atividades diárias,\nhumor e medicações") >> mobile_app
    usuario >> Edge(label="Acessa via navegador") >> web_app
    cuidador >> Edge(label="Monitora progresso") >> web_app
    profissional_saude >> Edge(label="Analisa dados e\nfornece recomendações") >> web_app
    
    # Conexões de aplicações cliente para sistema principal
    mobile_app >> Edge(label="Envia/recebe dados") >> neurotrack
    web_app >> Edge(label="Envia/recebe dados") >> neurotrack
    
    # Conexões com sistemas externos
    neurotrack >> Edge(label="Solicita análises\ne recomendações") >> openai
    neurotrack >> Edge(label="Sincroniza eventos\ne compromissos") >> google_calendar
    neurotrack >> Edge(label="Envia alertas\ne lembretes") >> notificacoes
    notificacoes >> Edge(label="Notifica") >> usuario
