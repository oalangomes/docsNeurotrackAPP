from diagrams import Diagram, Cluster, Edge
from diagrams.onprem.client import User
from diagrams.onprem.compute import Server
from diagrams.onprem.database import MongoDB
from diagrams.programming.framework import React
from diagrams.onprem.network import Nginx
from diagrams.aws.storage import SimpleStorageServiceS3
from diagrams.aws.ml import Rekognition
from diagrams.gcp.compute import AppEngine
from diagrams.onprem.queue import Kafka
from diagrams.programming.language import Javascript
from diagrams.generic.network import Firewall
from diagrams.generic.network import Subnet
from diagrams.generic.os import Windows, IOS, Android

# Criar diagrama de integração com serviços externos
with Diagram("NeurotrackApp - Integração com Serviços Externos", show=False, direction="TB", filename="diagrama_integracao_servicos_externos"):
    
    # Usuário
    usuario = User("Usuário\n(Pessoa Neurodivergente)")
    
    # Aplicações cliente
    with Cluster("Dispositivos Cliente"):
        mobile_ios = IOS("Aplicativo iOS")
        mobile_android = Android("Aplicativo Android")
        web_app = Windows("Aplicação Web")
    
    # Sistema NeurotrackApp
    with Cluster("Sistema NeurotrackApp"):
        # API Gateway
        api_gateway = Nginx("API Gateway\n(Express.js)")
        
        # Serviços de Integração
        with Cluster("Serviços de Integração"):
            ai_adapter = Javascript("Adaptador OpenAI")
            calendar_adapter = Javascript("Adaptador Google Calendar")
            notification_adapter = Javascript("Adaptador de Notificações")
            auth_adapter = Javascript("Adaptador de Autenticação")
        
        # Camada de Segurança
        firewall = Firewall("Camada de Segurança")
    
    # Serviços Externos
    with Cluster("Serviços Externos"):
        # OpenAI
        with Cluster("Serviço de IA"):
            openai_api = Rekognition("OpenAI API")
            openai_models = Rekognition("Modelos GPT")
        
        # Google Calendar
        with Cluster("Serviço de Agenda"):
            google_auth = AppEngine("Google OAuth")
            google_calendar = AppEngine("Google Calendar API")
        
        # Serviço de Notificações
        with Cluster("Serviço de Notificações"):
            push_service = Kafka("Serviço de Push")
            email_service = Kafka("Serviço de Email")
    
    # Conexões de usuário para dispositivos
    usuario >> mobile_ios
    usuario >> mobile_android
    usuario >> web_app
    
    # Conexões de dispositivos para API Gateway
    mobile_ios >> Edge(label="HTTPS") >> api_gateway
    mobile_android >> Edge(label="HTTPS") >> api_gateway
    web_app >> Edge(label="HTTPS") >> api_gateway
    
    # Conexões através do firewall
    api_gateway >> firewall
    
    # Conexões para serviços de integração
    firewall >> ai_adapter
    firewall >> calendar_adapter
    firewall >> notification_adapter
    firewall >> auth_adapter
    
    # Conexões para serviços externos
    ai_adapter >> Edge(label="API Key Auth") >> openai_api
    openai_api >> openai_models
    
    calendar_adapter >> Edge(label="OAuth 2.0") >> google_auth
    google_auth >> google_calendar
    
    notification_adapter >> Edge(label="API Key Auth") >> push_service
    notification_adapter >> Edge(label="SMTP") >> email_service
    
    # Fluxo de retorno
    push_service >> Edge(label="Push Notification") >> mobile_ios
    push_service >> Edge(label="Push Notification") >> mobile_android
    email_service >> Edge(label="Email") >> usuario
