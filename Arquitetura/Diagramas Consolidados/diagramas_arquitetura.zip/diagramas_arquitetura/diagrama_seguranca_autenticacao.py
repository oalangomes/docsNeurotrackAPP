from diagrams import Diagram, Cluster, Edge
from diagrams.onprem.client import User
from diagrams.onprem.compute import Server
from diagrams.onprem.database import MongoDB
from diagrams.onprem.network import Nginx
from diagrams.aws.security import IAM, WAF, Shield
from diagrams.aws.storage import SimpleStorageServiceS3
from diagrams.gcp.security import IAP, KMS
from diagrams.generic.network import Firewall
from diagrams.generic.os import IOS, Android
from diagrams.generic.place import Datacenter
from diagrams.programming.language import Javascript
from diagrams.programming.framework import React

# Criar diagrama de segurança e autenticação
with Diagram("NeurotrackApp - Segurança e Autenticação", show=False, direction="TB", filename="diagrama_seguranca_autenticacao"):
    
    # Usuários e Dispositivos
    with Cluster("Usuários e Dispositivos"):
        usuario = User("Usuário")
        mobile_ios = IOS("Aplicativo iOS")
        mobile_android = Android("Aplicativo Android")
        web_app = React("Aplicação Web")
    
    # Camada de Rede e Proteção
    with Cluster("Camada de Rede e Proteção"):
        waf = WAF("Firewall de Aplicação Web")
        firewall = Firewall("Firewall de Rede")
        ddos_protection = Shield("Proteção DDoS")
    
    # API Gateway e Autenticação
    with Cluster("API Gateway e Autenticação"):
        api_gateway = Nginx("API Gateway")
        
        with Cluster("Serviços de Autenticação"):
            auth_service = Javascript("Serviço de Autenticação")
            token_service = Javascript("Serviço de Tokens")
            oauth_service = Javascript("Serviço OAuth")
            
        with Cluster("Middleware de Segurança"):
            auth_middleware = Javascript("Middleware de Autenticação")
            rate_limiter = Javascript("Limitador de Taxa")
            input_validator = Javascript("Validador de Entrada")
    
    # Armazenamento Seguro
    with Cluster("Armazenamento Seguro"):
        mongodb = MongoDB("MongoDB\n(Dados Criptografados)")
        redis = SimpleStorageServiceS3("Redis\n(Cache de Tokens)")
        key_manager = KMS("Gerenciador de Chaves")
    
    # Serviços Protegidos
    with Cluster("Serviços Protegidos"):
        user_service = Server("Serviço de Usuários")
        daily_service = Server("Serviço de Entradas Diárias")
        task_service = Server("Serviço de Tarefas")
        ai_service = Server("Serviço de IA")
        agenda_service = Server("Serviço de Agenda")
        med_service = Server("Serviço de Medicação")
    
    # Fluxo de Autenticação - Dispositivos para Proteção
    usuario >> mobile_ios
    usuario >> mobile_android
    usuario >> web_app
    
    mobile_ios >> Edge(label="HTTPS") >> waf
    mobile_android >> Edge(label="HTTPS") >> waf
    web_app >> Edge(label="HTTPS") >> waf
    
    # Fluxo de Proteção
    waf >> ddos_protection
    ddos_protection >> firewall
    
    # Fluxo para API Gateway
    firewall >> api_gateway
    
    # Fluxo de Autenticação
    api_gateway >> auth_middleware
    auth_middleware >> auth_service
    
    # Serviços de Autenticação
    auth_service >> token_service
    auth_service >> oauth_service
    
    # Middleware de Segurança
    auth_middleware >> rate_limiter
    auth_middleware >> input_validator
    
    # Armazenamento Seguro
    token_service >> redis
    auth_service >> mongodb
    mongodb >> Edge(label="Criptografia") >> key_manager
    redis >> Edge(label="Criptografia") >> key_manager
    
    # Acesso a Serviços Protegidos
    auth_middleware >> Edge(label="Autoriza") >> user_service
    auth_middleware >> Edge(label="Autoriza") >> daily_service
    auth_middleware >> Edge(label="Autoriza") >> task_service
    auth_middleware >> Edge(label="Autoriza") >> ai_service
    auth_middleware >> Edge(label="Autoriza") >> agenda_service
    auth_middleware >> Edge(label="Autoriza") >> med_service
