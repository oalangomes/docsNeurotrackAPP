from diagrams import Diagram, Cluster, Edge
from diagrams.onprem.client import User, Client
from diagrams.onprem.compute import Server
from diagrams.onprem.database import MongoDB
from diagrams.saas.chat import Slack
from diagrams.programming.framework import React
from diagrams.onprem.network import Nginx
from diagrams.aws.integration import Eventbridge
from diagrams.generic.database import SQL
from diagrams.gcp.compute import AppEngine
from diagrams.aws.ml import Rekognition
from diagrams.aws.storage import SimpleStorageServiceS3
from diagrams.aws.database import RDS
from diagrams.onprem.queue import Kafka
from diagrams.onprem.container import Docker

# Criar diagrama C4 de container detalhado
with Diagram("NeurotrackApp - Diagrama de Containers", show=False, direction="TB", filename="c4_container_detalhado"):
    
    # Usuários
    usuario = User("Usuário\n(Pessoa Neurodivergente)")
    
    # Aplicações cliente
    mobile_app = Client("Aplicativo Móvel\n(React Native)")
    web_app = Client("Aplicação Web\n(React.js)")
    
    # Containers do sistema
    with Cluster("Sistema NeurotrackApp"):
        # API Gateway
        api_gateway = Nginx("API Gateway\n(Express.js)")
        
        # Serviços Backend
        with Cluster("Backend Services"):
            auth_service = Docker("Serviço de Autenticação\n(Node.js)")
            user_service = Docker("Serviço de Usuários\n(Node.js)")
            task_service = Docker("Serviço de Tarefas\n(Node.js)")
            daily_entry_service = Docker("Serviço de Entradas Diárias\n(Node.js)")
            ai_service = Docker("Serviço de IA\n(Node.js)")
            agenda_service = Docker("Serviço de Agenda\n(Node.js)")
            medication_service = Docker("Serviço de Medicação\n(Node.js)")
        
        # Bancos de dados
        with Cluster("Persistência de Dados"):
            mongodb = MongoDB("MongoDB\n(Dados Principais)")
            redis = SimpleStorageServiceS3("Redis\n(Cache)")
            
        # Mensageria
        message_broker = Kafka("Message Broker\n(Notificações)")
    
    # Sistemas externos
    openai_api = Rekognition("OpenAI API\n(Serviço de IA)")
    google_calendar = AppEngine("Google Calendar API\n(Serviço de Agenda)")
    
    # Conexões de usuários para aplicações
    usuario >> Edge(label="Usa") >> mobile_app
    usuario >> Edge(label="Usa") >> web_app
    
    # Conexões de aplicações para API Gateway
    mobile_app >> Edge(label="API Calls (HTTPS)") >> api_gateway
    web_app >> Edge(label="API Calls (HTTPS)") >> api_gateway
    
    # Conexões do API Gateway para serviços
    api_gateway >> Edge(label="Autentica") >> auth_service
    api_gateway >> Edge(label="Gerencia usuários") >> user_service
    api_gateway >> Edge(label="Gerencia tarefas") >> task_service
    api_gateway >> Edge(label="Registra entradas") >> daily_entry_service
    api_gateway >> Edge(label="Processa IA") >> ai_service
    api_gateway >> Edge(label="Gerencia agenda") >> agenda_service
    api_gateway >> Edge(label="Gerencia medicações") >> medication_service
    
    # Conexões de serviços para bancos de dados
    auth_service >> Edge(label="Armazena") >> mongodb
    user_service >> Edge(label="Armazena") >> mongodb
    task_service >> Edge(label="Armazena") >> mongodb
    daily_entry_service >> Edge(label="Armazena") >> mongodb
    agenda_service >> Edge(label="Armazena") >> mongodb
    medication_service >> Edge(label="Armazena") >> mongodb
    
    # Conexões para cache
    auth_service >> Edge(label="Cache") >> redis
    user_service >> Edge(label="Cache") >> redis
    
    # Conexões para mensageria
    task_service >> Edge(label="Publica") >> message_broker
    daily_entry_service >> Edge(label="Publica") >> message_broker
    medication_service >> Edge(label="Publica") >> message_broker
    message_broker >> Edge(label="Notifica") >> usuario
    
    # Conexões para sistemas externos
    ai_service >> Edge(label="Integra") >> openai_api
    agenda_service >> Edge(label="Sincroniza") >> google_calendar
