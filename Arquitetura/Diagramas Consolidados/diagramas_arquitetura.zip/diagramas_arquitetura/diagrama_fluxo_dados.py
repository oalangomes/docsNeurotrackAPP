from diagrams import Diagram, Cluster, Edge
from diagrams.onprem.client import User
from diagrams.onprem.compute import Server
from diagrams.onprem.database import MongoDB
from diagrams.programming.framework import React
from diagrams.onprem.network import Nginx
from diagrams.aws.storage import SimpleStorageServiceS3
from diagrams.aws.ml import Rekognition
from diagrams.gcp.compute import AppEngine
from diagrams.onprem.queue import Kafka
from diagrams.programming.language import Javascript
from diagrams.generic.database import SQL
from diagrams.generic.storage import Storage
from diagrams.generic.device import Mobile

# Criar diagrama de fluxo de dados do sistema
with Diagram("NeurotrackApp - Fluxo de Dados", show=False, direction="LR", filename="diagrama_fluxo_dados"):
    
    # Fontes de dados
    with Cluster("Fontes de Dados"):
        usuario = User("Usuário")
        mobile_app = Mobile("Aplicativo Móvel")
        web_app = React("Aplicação Web")
        
    # Processamento de Dados
    with Cluster("Processamento de Dados"):
        api_gateway = Nginx("API Gateway")
        
        with Cluster("Serviços de Processamento"):
            auth_service = Javascript("Serviço de Autenticação")
            user_service = Javascript("Serviço de Usuários")
            daily_service = Javascript("Serviço de Entradas Diárias")
            task_service = Javascript("Serviço de Tarefas")
            ai_service = Javascript("Serviço de IA")
            agenda_service = Javascript("Serviço de Agenda")
            med_service = Javascript("Serviço de Medicação")
    
    # Armazenamento de Dados
    with Cluster("Armazenamento de Dados"):
        mongodb = MongoDB("MongoDB\n(Dados Principais)")
        redis = SimpleStorageServiceS3("Redis\n(Cache)")
        
    # Análise de Dados
    with Cluster("Análise de Dados"):
        ai_engine = Rekognition("Motor de IA")
        analytics = SQL("Análise de Dados")
        
    # Saídas de Dados
    with Cluster("Saídas de Dados"):
        notifications = Kafka("Notificações")
        reports = Storage("Relatórios")
        calendar = AppEngine("Calendário")
    
    # Fluxos de Dados - Entrada
    usuario >> Edge(label="1. Insere dados") >> mobile_app
    usuario >> Edge(label="1. Insere dados") >> web_app
    
    mobile_app >> Edge(label="2. Envia requisições") >> api_gateway
    web_app >> Edge(label="2. Envia requisições") >> api_gateway
    
    # Fluxos para serviços
    api_gateway >> Edge(label="3. Autentica") >> auth_service
    api_gateway >> Edge(label="4. Gerencia perfil") >> user_service
    api_gateway >> Edge(label="5. Registra humor/atividades") >> daily_service
    api_gateway >> Edge(label="6. Gerencia tarefas") >> task_service
    api_gateway >> Edge(label="7. Processa IA") >> ai_service
    api_gateway >> Edge(label="8. Gerencia agenda") >> agenda_service
    api_gateway >> Edge(label="9. Gerencia medicações") >> med_service
    
    # Fluxos para armazenamento
    auth_service >> Edge(label="10. Armazena tokens") >> redis
    user_service >> Edge(label="11. Armazena perfis") >> mongodb
    daily_service >> Edge(label="12. Armazena entradas") >> mongodb
    task_service >> Edge(label="13. Armazena tarefas") >> mongodb
    agenda_service >> Edge(label="14. Armazena eventos") >> mongodb
    med_service >> Edge(label="15. Armazena medicações") >> mongodb
    
    # Fluxos para análise
    daily_service >> Edge(label="16. Analisa padrões") >> ai_engine
    task_service >> Edge(label="17. Decompõe tarefas") >> ai_engine
    
    ai_service >> Edge(label="18. Processa linguagem") >> ai_engine
    ai_engine >> Edge(label="19. Gera insights") >> analytics
    
    # Fluxos de saída
    analytics >> Edge(label="20. Gera") >> reports
    task_service >> Edge(label="21. Agenda") >> calendar
    med_service >> Edge(label="22. Programa") >> notifications
    
    # Fluxos de retorno
    notifications >> Edge(label="23. Alerta") >> usuario
    reports >> Edge(label="24. Informa") >> web_app
    calendar >> Edge(label="25. Sincroniza") >> mobile_app
