from diagrams import Diagram, Cluster, Edge
from diagrams.onprem.client import User
from diagrams.onprem.compute import Server
from diagrams.onprem.database import MongoDB
from diagrams.onprem.network import Nginx
from diagrams.aws.compute import EC2, Lambda, ECS
from diagrams.aws.database import ElastiCache, DocumentDB
from diagrams.aws.network import ELB, CloudFront, Route53
from diagrams.aws.storage import S3
from diagrams.aws.security import WAF
from diagrams.gcp.compute import GKE
from diagrams.gcp.network import LoadBalancing
from diagrams.generic.network import Firewall
from diagrams.generic.os import IOS, Android
from diagrams.generic.place import Datacenter

# Criar diagrama de implantação e infraestrutura
with Diagram("NeurotrackApp - Implantação e Infraestrutura", show=False, direction="TB", filename="diagrama_implantacao_infraestrutura"):
    
    # Usuários
    usuarios = User("Usuários")
    
    # DNS e CDN
    dns = Route53("DNS")
    cdn = CloudFront("CDN")
    
    # Proteção de Borda
    waf = WAF("WAF")
    
    # Balanceadores de Carga
    with Cluster("Balanceamento de Carga"):
        lb_frontend = ELB("Load Balancer\nFrontend")
        lb_backend = ELB("Load Balancer\nBackend")
    
    # Ambiente de Produção
    with Cluster("Ambiente de Produção"):
        # Frontend
        with Cluster("Frontend"):
            frontend_pods = [ECS("Frontend Pod 1"), 
                            ECS("Frontend Pod 2"),
                            ECS("Frontend Pod 3")]
        
        # Backend
        with Cluster("Backend (Microserviços)"):
            # API Gateway
            api_gateway = Nginx("API Gateway")
            
            # Serviços
            with Cluster("Serviços"):
                auth_service = ECS("Serviço de Autenticação")
                user_service = ECS("Serviço de Usuários")
                daily_service = ECS("Serviço de Entradas Diárias")
                task_service = ECS("Serviço de Tarefas")
                ai_service = ECS("Serviço de IA")
                agenda_service = ECS("Serviço de Agenda")
                med_service = ECS("Serviço de Medicação")
        
        # Bancos de Dados
        with Cluster("Bancos de Dados"):
            mongodb_primary = DocumentDB("MongoDB Primary")
            mongodb_replica1 = DocumentDB("MongoDB Replica 1")
            mongodb_replica2 = DocumentDB("MongoDB Replica 2")
            
            redis_primary = ElastiCache("Redis Primary")
            redis_replica = ElastiCache("Redis Replica")
    
    # Ambiente de Homologação
    with Cluster("Ambiente de Homologação"):
        staging_frontend = ECS("Frontend Staging")
        staging_backend = ECS("Backend Staging")
        staging_db = DocumentDB("MongoDB Staging")
    
    # Serviços de Suporte
    with Cluster("Serviços de Suporte"):
        logs = S3("Armazenamento de Logs")
        backups = S3("Backups")
        monitoring = Lambda("Monitoramento")
        ci_cd = Lambda("CI/CD Pipeline")
    
    # Serviços Externos
    with Cluster("Serviços Externos"):
        openai = Server("OpenAI API")
        google_calendar = Server("Google Calendar API")
        push_notification = Server("Serviço de Push")
    
    # Conexões de Usuários
    usuarios >> dns
    dns >> cdn
    cdn >> waf
    
    # Conexões de Balanceamento
    waf >> lb_frontend
    lb_frontend >> frontend_pods
    
    # Conexões de Frontend para Backend
    for pod in frontend_pods:
        pod >> lb_backend
    
    lb_backend >> api_gateway
    
    # Conexões de API Gateway para Serviços
    api_gateway >> auth_service
    api_gateway >> user_service
    api_gateway >> daily_service
    api_gateway >> task_service
    api_gateway >> ai_service
    api_gateway >> agenda_service
    api_gateway >> med_service
    
    # Conexões de Serviços para Bancos de Dados
    auth_service >> redis_primary
    user_service >> mongodb_primary
    daily_service >> mongodb_primary
    task_service >> mongodb_primary
    agenda_service >> mongodb_primary
    med_service >> mongodb_primary
    
    # Replicação de Bancos de Dados
    mongodb_primary >> mongodb_replica1
    mongodb_primary >> mongodb_replica2
    redis_primary >> redis_replica
    
    # Conexões para Serviços Externos
    ai_service >> openai
    agenda_service >> google_calendar
    med_service >> push_notification
    
    # Conexões para Serviços de Suporte
    api_gateway >> logs
    mongodb_primary >> backups
    redis_primary >> backups
    
    monitoring >> api_gateway
    monitoring >> mongodb_primary
    monitoring >> redis_primary
    
    ci_cd >> frontend_pods[0]
    ci_cd >> api_gateway
    
    # Conexões para Ambiente de Homologação
    ci_cd >> staging_frontend
    ci_cd >> staging_backend
    staging_backend >> staging_db
