from diagrams import Diagram, Cluster, Edge
from diagrams.onprem.client import User
from diagrams.onprem.compute import Server
from diagrams.onprem.database import MongoDB
from diagrams.programming.framework import React
from diagrams.onprem.network import Nginx
from diagrams.aws.storage import SimpleStorageServiceS3
from diagrams.aws.ml import Rekognition
from diagrams.gcp.compute import AppEngine
from diagrams.onprem.queue import Kafka
from diagrams.generic.compute import Rack
from diagrams.generic.storage import Storage
from diagrams.generic.place import Datacenter
from diagrams.programming.language import Javascript

# Criar diagrama C4 de componentes do backend
with Diagram("NeurotrackApp - Componentes do Backend", show=False, direction="TB", filename="c4_componentes_backend"):
    
    # API Gateway
    api_gateway = Nginx("API Gateway\n(Express.js)")
    
    # Componentes do Serviço de Autenticação
    with Cluster("Serviço de Autenticação"):
        auth_controller = Javascript("AuthController")
        auth_middleware = Javascript("AuthMiddleware")
        auth_service = Javascript("AuthService")
        token_service = Javascript("TokenService")
        
        auth_controller >> auth_service
        auth_service >> token_service
        auth_middleware >> token_service
    
    # Componentes do Serviço de Usuários
    with Cluster("Serviço de Usuários"):
        user_controller = Javascript("UserController")
        user_service = Javascript("UserService")
        user_repository = Javascript("UserRepository")
        
        user_controller >> user_service
        user_service >> user_repository
    
    # Componentes do Serviço de Tarefas
    with Cluster("Serviço de Tarefas"):
        task_controller = Javascript("TaskController")
        task_service = Javascript("TaskService")
        task_repository = Javascript("TaskRepository")
        task_breakdown = Javascript("TaskBreakdownService")
        
        task_controller >> task_service
        task_service >> task_repository
        task_service >> task_breakdown
    
    # Componentes do Serviço de Entradas Diárias
    with Cluster("Serviço de Entradas Diárias"):
        daily_controller = Javascript("DailyEntriesController")
        daily_service = Javascript("DailyEntriesService")
        daily_repository = Javascript("DailyEntriesRepository")
        mood_analyzer = Javascript("MoodAnalyzerService")
        
        daily_controller >> daily_service
        daily_service >> daily_repository
        daily_service >> mood_analyzer
    
    # Componentes do Serviço de IA
    with Cluster("Serviço de IA"):
        ai_controller = Javascript("AIController")
        ai_service = Javascript("AIService")
        prompt_service = Javascript("PromptService")
        ai_adapter = Javascript("AIAdapterService")
        
        ai_controller >> ai_service
        ai_service >> prompt_service
        ai_service >> ai_adapter
    
    # Componentes do Serviço de Agenda
    with Cluster("Serviço de Agenda"):
        agenda_controller = Javascript("AgendaController")
        agenda_service = Javascript("AgendaService")
        agenda_repository = Javascript("AgendaRepository")
        calendar_sync = Javascript("CalendarSyncService")
        
        agenda_controller >> agenda_service
        agenda_service >> agenda_repository
        agenda_service >> calendar_sync
    
    # Componentes do Serviço de Medicação
    with Cluster("Serviço de Medicação"):
        med_controller = Javascript("MedicationController")
        med_service = Javascript("MedicationService")
        med_repository = Javascript("MedicationRepository")
        reminder_service = Javascript("ReminderService")
        
        med_controller >> med_service
        med_service >> med_repository
        med_service >> reminder_service
    
    # Bancos de dados
    mongodb = MongoDB("MongoDB")
    redis = SimpleStorageServiceS3("Redis\n(Cache)")
    
    # Mensageria
    message_broker = Kafka("Message Broker")
    
    # Sistemas externos
    openai_api = Rekognition("OpenAI API")
    google_calendar = AppEngine("Google Calendar API")
    
    # Conexões do API Gateway para controllers
    api_gateway >> auth_controller
    api_gateway >> user_controller
    api_gateway >> task_controller
    api_gateway >> daily_controller
    api_gateway >> ai_controller
    api_gateway >> agenda_controller
    api_gateway >> med_controller
    
    # Conexões para bancos de dados
    user_repository >> mongodb
    task_repository >> mongodb
    daily_repository >> mongodb
    agenda_repository >> mongodb
    med_repository >> mongodb
    
    # Conexões para cache
    token_service >> redis
    user_service >> redis
    
    # Conexões para mensageria
    reminder_service >> message_broker
    task_service >> message_broker
    
    # Conexões para sistemas externos
    ai_adapter >> openai_api
    calendar_sync >> google_calendar
